(function () {
    "use strict";
    angular.module("countDown", [])
        .directive("countDown", function () {
            return {
                restrict: "E",
                templateUrl: "templates/countDown.html",
                link: function ($scope) {
                    var interval = null;
                    $scope.$on("startCountDown", function () {
                        var time = 260;
                        var initialOffset = '440';
                        var i = 1;
                        angular.element(document.getElementsByClassName('circle_animation')).css('stroke-dashoffset', initialOffset - (1 * (initialOffset / time)));
                        interval = setInterval(function () {
                            angular.element(document.getElementById('countDown')).append("<span>Seconds</span>").text(i);
                            if (i === time) {
                                clearInterval(interval);
                                $scope.$emit("timeUp", {});
                                return;
                            }
                            angular.element(document.getElementsByClassName('circle_animation')).css('stroke-dashoffset', initialOffset - ((i + 1) * (initialOffset / time)));
                            i++;
                        }, 1000);
                        return;
                    });

                    $scope.$on("successfullySolvedPuzzle", function () {
                        clearInterval(interval);
                        return;
                    });
                }
            }
        })
})();
