(function () {
    'use strict';
    angular.module("graphsContainerPanel", [])
        .directive("graphsContainerPanel", function ($timeout, dashboardFactory) {
            return {
                restrict: 'E',
                templateUrl: 'templates/graphsContainerPanel.html',
                link: function ($scope, element, attr) {
                    $scope.showOverlay = false;
                    $scope.canvasElement = null;
                    $scope.canvasContext = null;
                    $scope.chartInstance = null;
                    $scope.scales = ['scaleRight', 'scaleLeft'];
                    var globalChartSettings = {};
                    $scope.border = 1;
                    $scope.pointStyle = "circle";

                    $scope.onBefore5min = function (type, data) {
                        console.log($scope.line)
                        data = data !== undefined ? data : dashboardFactory.graphsData[0]['5min'];
                        type = type !== undefined ? type : 'line';
                        if ($scope.canvasContext) {
                            $scope.canvasContext.clearRect(0, 0, $scope.canvasElement.width, $scope.canvasElement.height);
                        }
                        if ($scope.chartInstance) {
                            $scope.chartInstance.destroy();
                        }
                        generateGraph(type, data);
                    };
                    $scope.onBefore15min = function (type, data) {
                        $scope.canvasContext.clearRect(0, 0, $scope.canvasElement.width, $scope.canvasElement.height);
                        $scope.chartInstance.destroy();
                        var data = dashboardFactory.graphsData[1]['15min'];
                        generateGraph(type, data);
                    };
                    $scope.onSettingsBtnClick = function () {
                        $scope.showOverlay = !$scope.showOverlay;
                    };

                    //CANVAS

                    function generateGraph(type, data) {
                        var options = {
                            type: type !== undefined ? type : 'line',
                            data: {
                                labels: ["Persistent", "TCS", "Infosys", "Wipro", "Cognizant", "Accenture", "IBM", "TechM"],
                                datasets: [
                                    {
                                        label: 'Share Value',
                                        data: data,
                                        borderWidth: globalChartSettings.borderWidth,
                                        // fill: 'start',
                                        lineTension: .0001,
                                        backgroundColor: "rgba(75,192,192,0.4)",
                                        borderColor: "rgba(75,192,192,1)",
                                        borderCapStyle: 'butt',
                                        borderDash: [],
                                        borderDashOffset: 0.0,
                                        borderJoinStyle: 'miter',
                                        pointBorderColor: "rgba(255,0,0,1)",
                                        pointBackgroundColor: "rgba(75,192,192,1)",
                                        pointBorderWidth: 1,
                                        pointHoverRadius: 15,
                                        pointHoverBackgroundColor: "rgba(75,192,192,1)",
                                        pointHoverBorderColor: "rgba(75,192,192,1)",
                                        pointHoverBorderWidth: 2,
                                        pointRadius: 5,
                                        pointHitRadius: 10,
                                        showLine: true // line shown
                                        // hoverBackgroundColor: "rgba(255,99,132,0.4)",
                                        // hoverBorderColor: "rgba(255,99,132,1)",
                                    }
                                ]
                            },
                            options: {
                                scales: {
                                    yAxes: [{
                                        ticks: {
                                            reverse: false
                                        }
                                    }]
                                },
                                elements: {
                                    point: {
                                        pointStyle: $scope.pointStyle
                                    }
                                }
                            }
                        };
                        $scope.canvasElement = document.getElementById('canvasContainer');
                        $scope.canvasContext = $scope.canvasElement.getContext('2d');
                        $scope.chartInstance = new Chart($scope.canvasContext, options);


                        // Chart.defaults.global.borderWidth = 10;

                        // Chart.defaults.global.animationSteps = 50;
                        // Chart.defaults.global.tooltipYPadding = 16;
                        // Chart.defaults.global.tooltipCornerRadius = 0;
                        // Chart.defaults.global.tooltipTitleFontStyle = "normal";
                        // Chart.defaults.global.tooltipFillColor = "rgba(0,160,0,0.8)";
                        // Chart.defaults.global.animationEasing = "easeOutBounce";
                        // Chart.defaults.global.responsive = true;
                        // Chart.defaults.global.scaleLineColor = "black";
                        // Chart.defaults.global.scaleFontSize = 16;
                    }

                    $timeout(function () {
                        var data = dashboardFactory.graphsData[0]['5min'];
                        $scope.onBefore5min('line', data);
                    }, 100);

                    //Color Picker
                    $("#line, #fill").spectrum({
                        showPaletteOnly: true,
                        togglePaletteOnly: true,
                        togglePaletteMoreText: 'more',
                        togglePaletteLessText: 'less',
                        color: 'blanchedalmond',
                        palette: [
                            ["#000", "#444", "#666", "#999", "#ccc", "#eee", "#f3f3f3", "#fff"],
                            ["#f00", "#f90", "#ff0", "#0f0", "#0ff", "#00f", "#90f", "#f0f"],
                            ["#f4cccc", "#fce5cd", "#fff2cc", "#d9ead3", "#d0e0e3", "#cfe2f3", "#d9d2e9", "#ead1dc"],
                            ["#ea9999", "#f9cb9c", "#ffe599", "#b6d7a8", "#a2c4c9", "#9fc5e8", "#b4a7d6", "#d5a6bd"],
                            ["#e06666", "#f6b26b", "#ffd966", "#93c47d", "#76a5af", "#6fa8dc", "#8e7cc3", "#c27ba0"],
                            ["#c00", "#e69138", "#f1c232", "#6aa84f", "#45818e", "#3d85c6", "#674ea7", "#a64d79"],
                            ["#900", "#b45f06", "#bf9000", "#38761d", "#134f5c", "#0b5394", "#351c75", "#741b47"],
                            ["#600", "#783f04", "#7f6000", "#274e13", "#0c343d", "#073763", "#20124d", "#4c1130"]
                        ]
                    });

                    //Settings

                    $scope.onDefaults = function () {
                        $scope.showOverlay = false;
                        $scope.border = 1;
                    };
                    $scope.onOK = function () {
                        $scope.showOverlay = false;
                        globalChartSettings.borderWidth = $scope.border;
                        $scope.onBefore5min();
                    };
                    $scope.onCancel = function () {
                        $scope.showOverlay = false;
                    };
                    $scope.onSettingsCloseIconClick = function () {
                        $scope.showOverlay = false;
                    };

                    //Full Screen
                    $scope.onFullScreenChart = function ($event) {
                        var graphContainer = angular.element(document.getElementsByClassName('graphContainer'));
                        var maximizeMinimizeIconElement = angular.element($event.target);
                        if (maximizeMinimizeIconElement.hasClass('glyphicon-fullscreen')) {
                            graphContainer.addClass('maximizeChart');
                            maximizeMinimizeIconElement.removeClass('glyphicon-fullscreen').addClass('glyphicon-resize-small');
                        } else {
                            maximizeMinimizeIconElement.removeClass('glyphicon-resize-small').addClass('glyphicon-fullscreen');
                            graphContainer.removeClass('maximizeChart');
                        }
                    };
                    //Export
                    $scope.onExportToImageClick = function ($event) {
                        if (window.navigator.msSaveOrOpenBlob) {
                            var blobObject = new Blob([document.getElementById('canvasContainer').toDataURL()], {type: "image/png"});
                            window.navigator.msSaveBlob(blobObject, 'graph.png')
                        } else {
                            var pngElement = document.getElementById('exportToPNG');
                            pngElement.href = document.getElementById('canvasContainer').toDataURL();
                            pngElement.download = "graph";
                        }

                    };
                    //Zoom
                    $scope.onZoomInClick = function () {

                    };
                    //On Pointer Intersection
                    $scope.onCrossPointer = function () {
                        $scope.pointStyle = "cross";
                        $scope.onBefore5min();
                    };
                    $scope.onDotPointer = function () {
                        $scope.pointStyle = "circle";
                        $scope.onBefore5min();

                    };
                    $scope.onArrowPointer = function () {
                        $scope.pointStyle = "triangle";
                        // $scope.chartInstance.update();
                        $scope.onBefore5min();

                    };
                    //Other Charts
                    $scope.onDisplayBarChart = function () {
                        $scope.onBefore5min("bar");
                    };
                    $scope.onDisplayLineChart = function () {
                        $scope.onBefore5min("line");
                    };
                    $scope.onDisplayAreaChart = function () {
                        $scope.onBefore5min("area");
                    };
                }
            }
        })
})();
