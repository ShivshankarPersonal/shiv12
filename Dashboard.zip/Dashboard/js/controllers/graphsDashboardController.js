(function () {
    angular.module("dashboard")
    .controller("graphsDashboard", function ($scope, $location, dashboardFactory) {
        $scope.pageName = "Graph Dashboard Page";
        // if (!sessionStorage.getItem('loginId')) {
        //     $location.path("/login");
        // }
        $scope.logoutBtn = true;
        $scope.onLogout = function () {
            $location.path("/login");
            sessionStorage.removeItem('loginId');
        };
        dashboardFactory.getGraphData().then(function (data) {

        }, function (data) {
            console.error(data)
        });
    });
})();